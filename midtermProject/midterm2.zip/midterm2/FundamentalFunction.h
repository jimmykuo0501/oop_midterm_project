//
// Created by Miller on 2025/3/31.
//

#ifndef FUNDAMENTALFUNCTION_H
#define FUNDAMENTALFUNCTION_H

#include <vector>
#include <iostream>

#define BOARDLENGTH 8

using namespace std;

class FundamentalFunction {
public:
    char board[BOARDLENGTH][BOARDLENGTH];
    // Initialize the board
    void initialize();

    // Show all place that user can take
    void showPlayPlace(bool);

    // Consider whether the step is available.
    void dedect(int xPos, int yPos, int moveX, int moveY, bool isWhiteTurn);

    // output the checkerboard in current time.
    void display() const;

    /*get x and y position, chess color and according to rule of black white chess to turn
      over the other color chess in each line.*/
    void turnOver(int, int, bool);

    bool checkWin(bool);
private:

};



#endif //FUNDAMENTAL_FUNCTION_H
