/*****************************************************************/ /**
 * \file   main.cpp
 * \brief
 *
 * \author Cheng-Jui,Kuo. (B11115063),
 * \date   2025/3/14~
 *********************************************************************/
#include <iostream>
#include <iomanip>
#include <vector>
#include "FundamentalFunction.h"

using namespace std;

int main() {
    FundamentalFunction newGame;
    newGame.initialize();
    newGame.display();
    cout << endl;
    newGame.showPlayPlace(true);
    newGame.display();

    // demo
    int row = 3, col = 0;
    newGame.turnOver(col, row, false);
    newGame.display();

    bool isWhiteTurn = true;
    while(1) {

    }

    return 0;
}

