//
// Created by Miller on 2025/4/9.
//

#ifndef PLAYER_H
#define PLAYER_H

class Player {
public:
    Player(): points(0), losses(0), wins(0) {};

    void addWinsPoints(int points);

    void addLossesPoints(int points);

    void addWinPoints(int points) ;

    int getPoints() const;

    int getLossesPoints() const;

    int getWinPoints() const;

private:
    int points;
    int losses;
    int wins;
};



#endif //PLAYER_H
