/*****************************************************************/ /**
 * \file   main.cpp
 * \brief
 *
 * \author 
 * \date   2025/3/14~
 *********************************************************************/
#include <iostream>
#include <iomanip>
#include <vector>
#include "FundamentalFunction.h"

using namespace std;
bool save();
void readFile(const string& fileName);

//this is main game program.
int main() {
    FundamentalFunction newGame;
    newGame.initialize();
    newGame.display();
    cout << endl;
    time_t gameTime = time(NULL);	//Record start time
    int passThisTurn = 0;
    double nowTime = 0;
    while (1)
    {
        
        int blackChessPositionX, blackChessPositionY;
        nowTime = time(NULL) - gameTime ;
        cout << "The remaining time is " << 3600-nowTime << "s.\n";
        if (nowTime >= 3600)
        {
            cout << "time out.\n";
            break;
        }
        cout << "Now is black chess player turn!\n";
        newGame.showPlayPlace(false);
        int findA = 0;
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (newGame.board[i][j] == 'a')
                {
                    findA = 1;
                    break;
                }
            }
        }
        if (!findA)
        {
            passThisTurn++;
            if (passThisTurn == 2) break;
            cout << "black chess player pass this turn.\n";
        }
        else {
            passThisTurn = 0;
            newGame.display();
            cout << "please input position: ";

            while (1)
            {
                cin >> blackChessPositionX >> blackChessPositionY;
                if (newGame.board[blackChessPositionX][blackChessPositionY] != 'a')
                {
                    cout << "input position error!!\n";
                }
                else {
                    break;
                }
            }

            newGame.playChess(blackChessPositionX, blackChessPositionY, false);

            newGame.turnOver(blackChessPositionX, blackChessPositionY, false);
            // change available point back to 's'
            for (auto& i : newGame.board) {
                for (auto& j : i) {
                    if (j == 'a') {
                        j = 's';
                    }
                }
            }
        }
        
        nowTime = time(NULL) - gameTime;
        cout << "The remaining time is " << 3600 - nowTime << "s.\n";
        if (nowTime >= 3600)
        {
            cout << "time out.\n";
            break;
        }
        cout << "Now is white chess player turn!\n";
        newGame.showPlayPlace(true);
        findA = 0;
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (newGame.board[i][j] == 'a')
                {
                    findA = 1;
                    break;
                }
            }
        }
        if (!findA)
        {
            passThisTurn++;
            if (passThisTurn == 2) break;
            cout << "white chess player pass this turn.\n";
        }
        else {
            passThisTurn = 0;
            newGame.display();
            cout << "please input position: ";
            while (1)
            {
                cin >> blackChessPositionX >> blackChessPositionY;
                if (newGame.board[blackChessPositionX][blackChessPositionY] != 'a')
                {
                    cout << "input position error!!\n";
                }
                else {
                    break;
                }
            }
            newGame.playChess(blackChessPositionX, blackChessPositionY, true);

            newGame.turnOver(blackChessPositionX, blackChessPositionY, true);

            // change available point back to 's'
            for (auto& i : newGame.board) {
                for (auto& j : i) {
                    if (j == 'a') {
                        j = 's';
                    }
                }
            }
        }
        //int remainTime = time(NULL) - gameTime;
        //cout << "The remaining time is " << remainTime /3600 << " hours " << (remainTime % 3600)/60 << "min" << (remainTime % 60) << "s.\n";
        //system("CLS");
    }
    int blackChess = 0, whiteChess = 0;
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            if (newGame.board[i][j] == 'b')
            {
                blackChess++;
            }else if (newGame.board[i][j] == 'w')
            {
                whiteChess++;
            }
        }
    }
    cout << "end of game\n";
    cout << "The result of this game is ";
    if (blackChess > whiteChess)
    {
        cout << "black one win.\n";
    }else if (blackChess < whiteChess)
    {
        cout << "white one win.\n";
    }
    else if (blackChess == whiteChess)
    {
        cout << "a tie.\n";
    }
}
// please call the following function with button.
bool save() {
    ofstream game;
    game.open("game.txt", ios::app);

    if (game.fail()) {
        return false;
    }
    else {
        game << time(NULL) << '-' << posX << '-' << posY << '-' << ((player) ? 'w' : 'b') << '\n';

        game.close();

        return true;
    }
}
void readFile(const string& fileName) {
    ifstream file;
    struct pos {
        int x;
        int y;
        bool isWhiteTurn;
    };
    file.open(fileName);
    if (file.is_open()) {
        vector<pos> position;
        string line;
        while (getline(file, line)) {
            cout << line << endl;
            // wait chan alen format
            testReadFile((line[1] - '0'), (line[2] - '0'), (line[0] == 'W') ? true : false);
        }
    }
    else {
        cout << "Error opening file " << fileName << endl;
    }
    file.close();
}

void testReadFile(int x, int y, bool isWhiteTurn) {
   

        int blackChessPositionX, blackChessPositionY;
        nowTime = time(NULL) - gameTime;
        cout << "The remaining time is " << 3600 - nowTime << "s.\n";
        if (nowTime >= 3600)
        {
            cout << "time out.\n";
            break;
        }
        cout << "Now is black chess player turn!\n";
        newGame.showPlayPlace(false);
        int findA = 0;
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (newGame.board[i][j] == 'a')
                {
                    findA = 1;
                    break;
                }
            }
        }
        if (!findA)
        {
            passThisTurn++;
            if (passThisTurn == 2) break;
            cout << "black chess player pass this turn.\n";
        }
        else {
            passThisTurn = 0;
            newGame.display();
            cout << "please input position: ";

            while (1)
            {
                cin >> blackChessPositionX >> blackChessPositionY;
                if (newGame.board[blackChessPositionX][blackChessPositionY] != 'a')
                {
                    cout << "input position error!!\n";
                }
                else {
                    break;
                }
            }

            newGame.playChess(blackChessPositionX, blackChessPositionY, false);

            newGame.turnOver(blackChessPositionX, blackChessPositionY, false);
            // change available point back to 's'
            for (auto& i : newGame.board) {
                for (auto& j : i) {
                    if (j == 'a') {
                        j = 's';
                    }
                }
            }
        }

        nowTime = time(NULL) - gameTime;
        cout << "The remaining time is " << 3600 - nowTime << "s.\n";
        if (nowTime >= 3600)
        {
            cout << "time out.\n";
            break;
        }
        cout << "Now is white chess player turn!\n";
        newGame.showPlayPlace(true);
        findA = 0;
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (newGame.board[i][j] == 'a')
                {
                    findA = 1;
                    break;
                }
            }
        }
        if (!findA)
        {
            passThisTurn++;
            if (passThisTurn == 2) break;
            cout << "white chess player pass this turn.\n";
        }
        else {
            passThisTurn = 0;
            newGame.display();
            cout << "please input position: ";
            while (1)
            {
                cin >> blackChessPositionX >> blackChessPositionY;
                if (newGame.board[blackChessPositionX][blackChessPositionY] != 'a')
                {
                    cout << "input position error!!\n";
                }
                else {
                    break;
                }
            }
            newGame.playChess(blackChessPositionX, blackChessPositionY, true);

            newGame.turnOver(blackChessPositionX, blackChessPositionY, true);

            // change available point back to 's'
            for (auto& i : newGame.board) {
                for (auto& j : i) {
                    if (j == 'a') {
                        j = 's';
                    }
                }
            }
        }
        //int remainTime = time(NULL) - gameTime;
        //cout << "The remaining time is " << remainTime /3600 << " hours " << (remainTime % 3600)/60 << "min" << (remainTime % 60) << "s.\n";
        //system("CLS");
    }
    int blackChess = 0, whiteChess = 0;
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            if (newGame.board[i][j] == 'b')
            {
                blackChess++;
            }
            else if (newGame.board[i][j] == 'w')
            {
                whiteChess++;
            }
        }
    
    cout << "end of game\n";
    cout << "The result of this game is ";
    if (blackChess > whiteChess)
    {
        cout << "black one win.\n";
    }
    else if (blackChess < whiteChess)
    {
        cout << "white one win.\n";
    }
    else if (blackChess == whiteChess)
    {
        cout << "a tie.\n";
    }
}

// the following program is for AI play chess

/*struct AIPlaySpace {
    int x;
    int y;
    int distanceWithEdge;
};
void AIPlayChess()
{
    AIPlaySpace choose[64] = { 0 };
    int chooseLength = 0;
    // AI is white
    showPlayPlace(true);
   
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            if (board[i][j] == 'a')
            {
                int minI = i;
                if ((8 - i) < minI)
                {
                    minI = (8 - i);
                }
                int minJ = j;
                if ((8 - j) < minJ)
                {
                    minJ = (8 - j);
                }
                if (minI < minJ) {
                    choose[chooseLength].distanceWithEdge = minI;
                }
                else {
                    choose[chooseLength].distanceWithEdge = minJ;
                }
                choose[chooseLength].x = i;
                choose[chooseLength].y = j;
                chooseLength++;
            }
        }
    }
    for (int i = 0; i < chooseLength; i++)
    {
        for (int j = 0; j < chooseLength; j++)
        {
            if (choose[i].distanceWithEdge > choose[j].distanceWithEdge)
            {
                int temp = choose[i].distanceWithEdge;
                choose[i].distanceWithEdge = choose[j].distanceWithEdge;
                choose[j].distanceWithEdge = temp;
            } 
        }
    }
    board[choose[0].x][choose[0].y] = 'w';
}*/
