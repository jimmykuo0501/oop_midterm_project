/*****************************************************************//**
 * \file   Global.h
 * \brief
 *
 * \author Alan
 * \date   2025/3/14
 *********************************************************************/
#pragma once

char board[8][8];

short posX = 0, posY = 0;

bool player = false;