//
// Created by Miller on 2025/3/31.
//

#include "FundamentalFunction.h"

/**
 * Initialize the board
 * This function haven't any input and return value.
 */
void FundamentalFunction::initialize() {
    for (auto& i : board) {
        for (char& j : i) {
            j = { 's' };
        }
    }

    board[3][3] = 'w';
    board[3][4] = 'b';
    board[4][3] = 'b';
    board[4][4] = 'w';
}

/**
 *  Show all place that user can take
 * \param isWhiteTurn. Who should play next (true is white turn, false is black turn)
 */
void FundamentalFunction::showPlayPlace(const bool isWhiteTurn) {
    // a mean available place
    const vector<vector<int> > dedection = { {-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0} };

    // change available point back to 's'
    for (auto& i : board) {
        for (auto& j : i) {
            if (j == 'a') {
                j = 's';
            }
        }
    }

    int locate = 0;
    if (isWhiteTurn) {
        while (locate < 64) {
            const int xPos = locate % 8;
            const int yPos = locate / 8;

            if (board[xPos][yPos] == 'w') {
                for (const vector<int>& dir : dedection) {
                    dedect(xPos, yPos, dir[0], dir[1], isWhiteTurn);
                   // FundamentalFunction::display();
                }
            }

            locate++;
        }
    }
    else if (!isWhiteTurn) {
        while (locate < 64) {
            const int xPos = locate % 8;
            const int yPos = locate / 8;

            if (board[xPos][yPos] == 'b') {
                for (const vector<int>& dir : dedection) {
                    dedect(xPos, yPos, dir[0], dir[1], isWhiteTurn);
                    //FundamentalFunction::display();
                }
            }

            locate++;
        }
    }
    
}
/**
 * Consider whether the step is available.
 * \param x posititon, y position, delta x, delta y, whose turn.
 */
void FundamentalFunction::dedect(int xPos, int yPos, const int moveX, const int moveY, const bool isWhiteTurn) {
    bool found = false;

    if (isWhiteTurn) {
        while (true) {
            xPos += moveX;
            yPos += moveY;

            if (xPos < 0 || xPos > 7 || yPos < 0 || yPos > 7) {
                break;
            }
            else if (board[yPos][xPos] == 'b') {
                found = true;
            }
            else if (board[yPos][xPos] == 's' && found) {
                board[yPos][xPos] = 'a';
                break;
            }
            else {
                break;
            }
        }
    }
    else {
        while (true) {
            xPos += moveX;
            yPos += moveY;

            if (board[yPos][xPos] == 'w') {
                found = true;
            }
            else if (board[yPos][xPos] == 's' && found) {
                board[yPos][xPos] = 'a';
                break;
            }
            else {
                break;
            }
        }
    }
}


/**
 * display function: output the checkerboard in current time.
 * This function haven't any input and return value.
 */
void FundamentalFunction::display() const {
    cout << "-----------------\n";

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            cout << "|";

            if (board[i][j] == 's')
            {
                cout << " ";
            }
            else if (board[i][j] == 'w')
            {
                cout << "��";
            }
            else if (board[i][j] == 'b')
            {
                cout << "��";
            }
            else if (board[i][j] == 'a')
            {
                cout << "��";
            }
        }

        cout << "|\n-----------------\n";
    }
}

/**
 *  get x and y position, chess color and according to rule of black white chess to turn
 *  over the other color chess in each line.
 *
 * \param xPos, this variable is to get chess x position.
 * \param yPos, this variable is to get chess y position.
 * \param isWhiteTurn, this variable is to check this chess color.
 */
void FundamentalFunction::turnOver(int xPos, int yPos, bool isWhiteTurn) {
    //cout << "***" << board[yPos][xPos] << endl;
    // searching centered on the white chess.
    if (isWhiteTurn) {
        // find the line of following eligible from the eight direstion of current chess.
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (board[yPos + i][xPos + j] == 'b') {
                    int findPointX = j, findPointY = i;
                    int findLine = 0;

                    // search one by one to find the chess is eligibility.
                    while (board[yPos + findPointY][xPos + findPointX] == 'b') {
                        findPointX += j;
                        findPointY += i;

                        if (board[yPos + findPointY][xPos + findPointX] == 's') {
                            findLine = 0;
                            break;
                        }

                        if (board[yPos + findPointY][xPos + findPointX] == 'w') {
                            findLine = 1;
                            break;
                        }
                    }

                    // turn over the black chess between two white chess in one line.
                    if (findLine) {
                        int startPointX, startPointY;
                        startPointY = yPos;
                        startPointX = xPos;
                        while (startPointY != (yPos + findPointY) || startPointX != (xPos + findPointX))
                        {
                            board[startPointY][startPointX] = 'w';
                            startPointY += i;
                            startPointX += j;
                        }
                    }
                    board[yPos + findPointY][xPos + findPointX] = 'w';
                }
            }
        }
    }
    // searching centered on the black chess.
    else {
        // find the line of following eligible from the eight direstion of current chess.
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (board[yPos + i][xPos + j] == 'w') {
                    int findPointX = j, findPointY = i;
                    int findLine = 0;

                    // search one by one to find the chess is eligibility.
                    while (board[yPos + findPointY][xPos + findPointX] == 'w') {
                        findPointX += j;
                        findPointY += i;

                        if (board[yPos + findPointY][xPos + findPointX] == 's') {
                            findLine = 0;
                            break;
                        }

                        if (board[yPos + findPointY][xPos + findPointX] == 'b') {
                            findLine = 1;
                            break;
                        }
                    }

                    // turn over the black chess between two white chess in one line.
                    if (findLine) {
                        int startPointX, startPointY;
                        startPointY = yPos;
                        startPointX = xPos;
                        //cout << startPointX << " " << startPointY << " " << xPos + findPointX << " " << yPos + findPointY << endl;
                        while (startPointY != (yPos + findPointY) || startPointX != (xPos + findPointX))
                        {
                            board[startPointY][startPointX] = 'b';
                            startPointY += i;
                            startPointX += j;
                            //cout << startPointX << " " << startPointY << endl;
                        }
                    }

                        board[yPos + findPointY][xPos + findPointX] = 'b';
                        
                    
                }
            }
        }
    }
    
}

/**
 * Place the chess on the given possition if it is a valid possition.
 *
 * \param posX
 * \param posY
 * \param player
 * \return
 */
bool FundamentalFunction::playChess(short x, short y, bool player) {
    if (board[y][x] == 'a') {
        board[y][x] = (player) ? 'w' : 'b';
        return true;
    }
    else {
        return false;
    }
}


/**
 * User input state.
 *
 * \return True if success,else false.
 */
/*bool FundamentalFunction::userInput() {
    time_t gameTime = time(NULL);

    while (time(NULL) - gameTime < 26) {
        if (_kbhit()) {
            switch (_getch()) {
            case 72:	//Up arrow
                if (posY > 0) posY--;
                break;
            case 80:	//Down arrow
                if (posY < 7) posY++;
                break;
            case 75:	//Left arrow
                if (posX > 0) posX--;
                break;
            case 77:	//Right arrow
                if (posX < 7) posX++;
                break;
            case 13:	//Enter
                if (playChess(posX, posY, player))
                    return true;
                else
                    cout << "Possition invalid!\n";
            }

            system("CLS");
            cout << posX << ' ' << posY << ' ' << ' ' << player << '\n';	//Debug message.
        }
    }

    return false;
}*/