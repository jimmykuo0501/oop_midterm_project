/*****************************************************************//**
 * \file   Player.cpp
 * \brief  Implementation a class is for player, definition method or function of player.
 *
 * \author Miller
 * \date   2025/4/9
 *********************************************************************/

#include "../headers/Player.h"

void Player::addWinsPoints(const int points) {
    this->wins += points;
}

void Player::addLossesPoints(const int points) {
    this->losses += points;
}

void Player::addWinPoints(const int points) {
    this->wins += points;
}

int Player::getPoints() const {
    return points;
}

int Player::getLossesPoints() const {
    return losses;
}

int Player::getWinPoints() const {
    return wins;
}
