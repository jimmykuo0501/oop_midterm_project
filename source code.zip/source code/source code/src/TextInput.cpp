/*****************************************************************//**
 * \file   TextInput.h
 * \brief  Change mouse click in the screen of the game to address of chess board, and next
 *         transfer the address to main program.
 *
 * \author Miller
 * \date   2025/4/9
 *********************************************************************/

#include "../headers/TextInput.h"
#include <SFML/Window/Mouse.hpp>

// Function to check if mouse button is pressed (missing in the header)
