//
// Created by Miller on 2025/4/9.
//

#include "../headers/TextInput.h"
#include <SFML/Window/Mouse.hpp>

// Function to check if mouse button is pressed (missing in the header)
